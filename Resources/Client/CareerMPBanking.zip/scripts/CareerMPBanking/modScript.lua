setExtensionUnloadMode('careerMPBanking', 'manual')
loadManualUnloadExtensions()
